import pytest
import numpy as np
from tsg.meta_generators import RegimeSwitchGenerator, MarkovSwitchGenerator
from tsg.generators import BaseGenerator


class DummyGenerator(BaseGenerator):
    """
    A simple dummy generator that always returns the same value.
    Used to test switching behavior.
    """
    def __init__(self, constant_value):
        self.constant_value = constant_value

    def generate_value(self, last_value=None):
        return self.constant_value

    def reset(self):
        pass


# === REGIME SWITCH GENERATOR ===

def test_regime_switch_generator_switching_behavior():
    """
    Test that RegimeSwitchGenerator switches between generators at specified steps.
    
    - gen1 returns 1
    - gen2 returns 10
    - Switch at steps 3 and 6
    - Expected behavior:
      Steps 0-2 -> gen1
      Steps 3-5 -> gen2
      Step 6-7 -> gen1 (wrap-around)
    """
    gen1 = DummyGenerator(1)
    gen2 = DummyGenerator(10)
    switch_times = [3, 6]
    regime_gen = RegimeSwitchGenerator([gen1, gen2], switch_times)

    expected = [1, 1, 1, 10, 10, 10, 1, 1]
    values = [regime_gen.generate_value() for _ in range(8)]
    assert values == expected


def test_regime_switch_generator_reset():
    """
    Test that reset brings RegimeSwitchGenerator back to initial state.

    - After some steps, reset should:
      - Reset step count to 0
      - Reset generator index to 0 (first generator)
      - Ensure first value after reset comes from gen1
    """
    gen1 = DummyGenerator(5)
    gen2 = DummyGenerator(15)
    regime_gen = RegimeSwitchGenerator([gen1, gen2], [2])

    for _ in range(4):  # Move past a switch
        regime_gen.generate_value()

    regime_gen.reset()
    assert regime_gen.generate_value() == 5  # Should return value from gen1 again


# === MARKOV SWITCH GENERATOR ===

def test_markov_switch_generator_alternating():
    """
    Test deterministic alternation in MarkovSwitchGenerator.

    - gen1 returns 100
    - gen2 returns -100
    - Transition matrix ensures switching between the two every step
    - Should alternate: 100, -100, 100, -100, ...
    """
    gen1 = DummyGenerator(100)
    gen2 = DummyGenerator(-100)
    transition_matrix = [[0.0, 1.0],  # from state 0 always go to state 1
                         [1.0, 0.0]]  # from state 1 always go to state 0
    markov_gen = MarkovSwitchGenerator([gen1, gen2], transition_matrix)

    values = [markov_gen.generate_value() for _ in range(6)]
    assert values[::2] == [100, 100, 100]    # Even-indexed steps: gen1
    assert values[1::2] == [-100, -100, -100]  # Odd-indexed steps: gen2


def test_markov_switch_generator_reset():
    """
    Test reset functionality of MarkovSwitchGenerator.

    - Set to state 1 manually
    - After reset, should return to initial state 0
    """
    gen1 = DummyGenerator(0)
    gen2 = DummyGenerator(1)
    markov_gen = MarkovSwitchGenerator([gen1, gen2], [[0.5, 0.5], [0.5, 0.5]])

    markov_gen.current_state = 1  # Force to different state
    markov_gen.reset()
    assert markov_gen.current_state == 0
